# Crypto_Exchange

* TradingView API.
- There are two types of requests — client and server. Client requests are executed at the browser. Server requests are initiated from the TradingView servers. If your integration does not imply brokerage data stream connection to the TradingView website - then there won't be any server requests
